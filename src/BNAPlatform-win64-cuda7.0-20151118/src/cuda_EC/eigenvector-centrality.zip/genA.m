 [ r,c,n ] = readcsr( 'E:\\cudaintergrated\\BNU_data_S2\\csrFormatTest\\N0003_25218_spa0.100%_cor0.644.csr');
   A  = csr2adjmat(n,r,c);
 
   [ec, D]= IPN_centEigenvector(A);
 