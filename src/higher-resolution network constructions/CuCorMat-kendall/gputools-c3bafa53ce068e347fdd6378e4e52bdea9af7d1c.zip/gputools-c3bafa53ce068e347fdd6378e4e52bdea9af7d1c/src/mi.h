void bSplineMutualInfo(int nbins, int order, int nsamples, int nx,
	const float * x, int ny, const float * y, float * out_mi);
